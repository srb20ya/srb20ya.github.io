#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <winsock.h>

#define SERVER_PORT 4242

#define VERSIONSTRING "SRB2 v1.1 Private Beta Sep 24 2008"
#define VERSIONSTRING2 "SRB2 v1.1 Private Beta Aug 22 2008"


SOCKET CreateListener(void)
{
	SOCKADDR_IN sockAddrListen;
	SOCKET sockListen;
	char szHostName[1024];
	HOSTENT* lphostent;

	// create a socket
	// bunch of error catching crap
	sockListen = socket(AF_INET, SOCK_STREAM, 0);
	if(sockListen == INVALID_SOCKET)
	{
		printf("Could not create socket: %d\n", WSAGetLastError());
		return INVALID_SOCKET;
	}

	if(gethostname(szHostName, 1024) == SOCKET_ERROR)
	{
		printf("Could not get host name: %d\n", WSAGetLastError());
		return INVALID_SOCKET;
	}

	lphostent = gethostbyname(szHostName);

	if(lphostent == NULL)
	{
		printf("Could not get host information: %d\n", WSAGetLastError());
		return INVALID_SOCKET;
	}

	// NOW we can do the real stuff.
	memset(&sockAddrListen, 0, sizeof(SOCKADDR_IN));
	// Specify the port number
	sockAddrListen.sin_port = htons(SERVER_PORT);
	// Specify address family as Internet
	sockAddrListen.sin_family = AF_INET;
	// Bind to ALL addresses
	sockAddrListen.sin_addr.s_addr = INADDR_ANY;

	// Bind socket with the SOCKADDR_IN structure
	if(bind(sockListen, (LPSOCKADDR)&sockAddrListen, sizeof(SOCKADDR)) == SOCKET_ERROR)
	{
		printf("Could not bind socket: %d\n", WSAGetLastError());
		return INVALID_SOCKET;
	}

	// Listen for a connection
	if(listen(sockListen, 1) == SOCKET_ERROR)
	{
		printf("Could not listen on socket: %d\n", WSAGetLastError());
		return INVALID_SOCKET;
	}

	return sockListen;
}

DWORD WINAPI SockThread(void)
{
	WSADATA wsaData;
	SOCKET sockConnected, sockListen;
	int nReceive, nSent;
	char szBuffer[1024];
	SOCKADDR_IN sockAddrClient;
	int nAddrLen = sizeof(SOCKADDR_IN);
	char ClientIP[64];
	char date[16];
	char time[16];
	FILE *f = NULL;

	printf("Thread started...\n");

	// Initialize WinSock
	if(WSAStartup(MAKEWORD(1, 1), &wsaData) != 0)
	{
		printf("Could not initialize sockets.\n");
		return 1;
	}

	sockListen = CreateListener();

	while(1)
	{
		if (f)
		{
			fclose(f);
			f = NULL;
		}

		printf("Waiting for connection...\n");

		// Block until a socket attempts to connect
		sockConnected = accept(sockListen, (LPSOCKADDR)&sockAddrClient, &nAddrLen);

		sprintf(ClientIP, "%u.%u.%u.%u", sockAddrClient.sin_addr.S_un.S_un_b.s_b1,
			sockAddrClient.sin_addr.S_un.S_un_b.s_b2,
			sockAddrClient.sin_addr.S_un.S_un_b.s_b3,
			sockAddrClient.sin_addr.S_un.S_un_b.s_b4);

		f = fopen("log.txt", "a");

		GetDateFormat(LOCALE_NEUTRAL, 0, NULL, "MM/dd/yyyy", date, 16);
		GetTimeFormat(LOCALE_NEUTRAL, 0, NULL, "h:mm:ss tt", time, 16);

		fprintf(f, "Connection from %s (%s; %s)\n", ClientIP, date, time);

		if(sockConnected == INVALID_SOCKET)
		{
			fprintf(f, "Could not accept a connection: %d", WSAGetLastError());
			break;
		}

		if(sockConnected != INVALID_SOCKET)
		{
			// accept strings from client
			{
				nReceive = recv(sockConnected, szBuffer, 1024, 0);
				if(nReceive == 0)
				{
					fprintf(f, "Connection broken\n");
					goto Doneness;
				}
				else if(nReceive == SOCKET_ERROR)
				{
					fprintf(f, "Error receiving: %d", WSAGetLastError());
					goto Doneness;
				}

				// print out received string
				fprintf(f, "Received %s\n", szBuffer);

				if (!strcmp(szBuffer, VERSIONSTRING) || !strcmp(szBuffer, VERSIONSTRING2))
					nReceive = 42;
				else
					nReceive = 0;

				// Send acknowledgement
				nSent = send(sockConnected, (char*)&nReceive, sizeof(nReceive), 0);
				
				if(nSent == SOCKET_ERROR)
				{
					fprintf(f, "Cannot send ack: %d", WSAGetLastError());
					goto Doneness;
				}
			}

Doneness:

			// Connection broken, clean up
			shutdown(sockConnected, 2);
			closesocket(sockConnected);
		}
	}

	// Clean up WinSock
	if(WSACleanup() == SOCKET_ERROR)
	{
		fprintf(f, "Could not cleanup sockets.\n");
		return 1;
	}

	fprintf(f, "Goodbye!\n");
	return 0;
}

int main (int argc, char* argv[])
{
	SockThread();

	return 0;
}