Sonic Robo Blast 2
Christmas Edition TEST v0.96CD
by Sonic Team Junior
09-09-2000
(readme by A.J. & Johnny)
-------------------

PREFACE
=======

Thanks for installing SRB2:XMAS Test.

VERSION HISTORY
===============

v0.90 - Initial (unofficial) release.
v0.92 - Initial (official) release.
v0.93 - Third release.
v0.94 - Fourth release.
v0.96CD - First CD release.

'PLOT'.
=======

Sonic has recieved an invitation from Eggman! He wants Sonic to travel to his Eggbase
for a Christmas reunion! However, Eggman's robots are well positioned everywhere,
to actually give Eggman time to prepare while he's cooking!

It's up to Sonic to beat the robots and drink eggnog with Eggman in his Eggbase...
that last bit sounded really freaky, didn't it?

BUG FIXES
=========

KEY:
- means a removed feature, probably due to it being buggy / no-one liked it.
+ means a new feature has been added to this version.
F bug fix.

v0.90 - Initial release.

v0.92 - Official release of SRB2:XMAS
F SIGSEGV is suppressed. Almost. The chances of getting SIGSEGV are about 15%,
but it's far better than in SRB2:XMAS original.
+ Re-enabled menus for those of you who really want the useless options back, I
don't know why you all wanted them though. O_o
F Those who couldn't launch the program should now have no problems.
+ A few more secrets & items. If you look hard enough, you might find some new items!

v0.93 - Third release.
F Temporary invulnerability added if you get hurt now. (Effectively removing
one-hit kills even with rings, or Neo-Killing Dead)
- Everyone agreed that the 'Useless Options' were useless, so they're finally
gone. Hurray.
+ Lives, see below for what you get on the various skill levels.
+ Score and time! Just like the Sonic games, and you get a countdown at the
end of the level for any remaining rings and time bonus!
+ Tails! His sprite is incomplete, so we're using the Sonic 3 sprite, but
he can fly!
F Multiplayer now works. Try network play with a friend!
+ On 'Cakewalk' skill, falling into a death pit (blackness) will throw you
back out.
+ On 'Very Hard' skill, all the rings have been removed! On top of this,
enemies are still faster, smarter and are auto-rebuilt after you destroy them!
- We've decided that people preffered the Air Spin Attack to the Homing Spin
Attack, so Sonic will now just get a huge speed boost instead.
+ Other stuff we don't want to tell you about. =)
- Many users may have problems starting the game or levels, with the game
  crashing out on them. But if you do get it to work, you can be nearly
  guaranteed it will not crash afterwards in that session. v0.95 will fix this
  problem.

v0.94 - Fourth release. (aka "The Big Fix")
F You can now hit enemies from underneath, and also chop them up with Tails' blades.
F Enemies can no longer destroy item boxes.
F Powerup timing corrected.
F Quicker underwater descent.
F Spindash only uses one button. Similar to Sonic Adventure.
F Fixed the sploosh bug from items spawning on the ground underwater
F The water timer will no longer continue if you are riding out of the water on a
  fan or spring.
F A bug in the 'Very Hard' skill level destroyed EVERYTHING (not just rings)
  making some levels impossible to complete. This has been fixed now.
+ The camera can now sometimes detect when it's "stuck" and will reposition itself.
+ Analog player control. Character moves in the direction the camera is facing. Hold
  down left or right to walk in a circle. Still needs some work. There is an option to
  turn this on and off in the Options menu. Analog will not work during multiplayer.
+ Armageddon shield added. Kills lots of enemies on your screen. Double jump to
  activate.
+ Elemental shield added. Protects you from the "elements", i.e. water, lava, and
  the like.
F Now compatible with user characters.
F You no longer ricochet off small enemies.

v0.96CD - CD release.
+ The latest SRB2 build as of 09/09/2000
+ CD Audio.
+ - As above, with bonuses such some extra levels and other surprises we're not
    going to mention. ^_^ The CD version is NOT network play compatible with the
    internet version, but that doesn't mean you can't try it!
- Don't run about too quickly, the old Christmas levels aren't designed to handle
  Sonic's high speed. The following levels have NOT been "fixed" of this problem:
  MAP05
  MAP07
  MAP08
  MAP09
  Secret Level 2
  A good way to avoid from going out of the play area is to play as Tails.
+ If you're interested in different stats, especially if you're making a level,
  try -debug !

ABOUT
=====

This test demonstrates all of the current technology of SRB2. Below is
how to use all of it. ^_^

First off, you can change controls by going to Options/Setup Controls...
and don't complain about the controls! I'd like you to name one PC game
(UltraHLE and Earthworm Jim 3D don't count) where the character moves like
an analog stick. These are being programmed in.

The "Air Spin Attack" is the equivalent of pressing the jump
button twice in Sonic Adventure. Unlike Sonic Adventure, the attack does
NOT home in, but instead makes Sonic have a huge speed boost.

The camera code has some new, improved features, but be sure NOT to bind
any keys to these while configuring the controls, remember that you can
turn off the Chasecam both in the Options menu and in the console, using
'CHASECAM OFF':

C = Resets the camera. Good for if it gets stuck. (Snow Mountain!!!!!)
V = Put camera view in front of Sonic. This can look cool for parts of the EggBase,
    running through the collapsing ceilings. =) Turn it on immediately after you
    go over the small pit if you take the middle path in Eggbase for some really cool
    Sonic Adventure-esque effects!
B = restores the camera view to behind Sonic if you had it in front of him.

That should cover about everything. If you find any bugs that aren't
listed above, please let me know at ah518@tcnet.org

DIFFICULTY
==========

Depending on what skill level you should choose, this will show you how many
lives and continues you'll get with each skill level.

CAKEWALK        - 9 lives, can't die by falling into death pits. Few robots.
EASY            - 6 lives, few robots.
NORMAL          - 5 lives, average number of robots.
HARD            - 3 lives, lots of robots.
VERY HARD       - 1 life, no rings, lots of smarter, faster robots.

FAQ
===

From the SRB2 FAQ:
(http://ssrg.emulationzone.org/stjr/updates/srb2faq.htm)

i. The game is way too bright!

...They're ice texures, what do you expect? ^_^

Seriously, there's a gamma correction / brightness option which you can change
from the options screen. Laptops also suffer badly from this - but then again,
the ORIGINAL DooM was pretty poor with a laptop, use a PC instead.

ii. That freakin' chasecam is annoying me!

Use the 'C' key to reset it.

iii. Hey! You removed some options from the early versions!

They were completely useless or allowed you to cheat through the game. First
everyone says the game will be too much like Sonic DooM 2 and now you want
'Bloodtime' back... make up your mind. If you want bloodtime, get Sonic DooM
2.

iv. Woah! The Air Spin Attack is very unstable!

It's not perfected yet, but it's a lot better than it was in v0.90! ;-)

v. The sprite is weird!

The sprite is more complete than the one seen in SRB2: Halloween Test, but it's
still not complete. Better to half of Sonic X-Treme and half of our sprite than
none at all.

Tails' sprite is VERY incomplete. You will get a very glitchy sprite if you use
Tails, but his special skills are still functional.

vi. How the heck do I beat Eggman on Very Hard?

It's extremerly difficult. Sonic can just about outrun Eggman's constant missiles,
Tails may have to use stealth and stratergy to beat him. If you're getting this far
on 'Very Hard' though, that's an incredible achievement, and you should be able to
breeze through SRB2 Final without any problems.

vii. The game crashes with a SIGSEGV error when I double click on it.

It's not gone yet, it'll be vanquished by 0.95, in the meantime, start an ANTI-
SIGSEGV fan club against it. That usually works.

viii. Where are the secrets?! Why are there only six levels?! Where's the gameplay?!
You and this game suck!

Note the word 'TEST' - we developed this to show the current technology we had,
not a complete game. Would you rather we added secrets to SRB2:XMAS and spent
some more time on that, meaning a longer wait for SRB2 normal, or more for SRB2
normal when it comes out? This version has some more secrets, and you can grab
add-on levels from the Mod Archives (URL below), but it's still NOT INTENDED
as a full game.

MODS AND CONTESTS!
==================

Check out the STJr page for level editing and future mods / patches we'll be making
for the game! We'll also be running a contest, check out the page in the future! And 
times will be posted on the Sonic Team Jr. Website!

http://stjr.cjb.net
http://ssrg.emulationzone.org/stjr

The mods archives - downloadable SRB2:XMAS goodies from here:
http://stjr.segasonic.net

Special thanks to previous Christmas Doom mods!
